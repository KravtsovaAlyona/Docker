package com.example.employees;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.Random;


@Component
public class DataLoader implements CommandLineRunner {
    @Autowired
    private EmployeeRepository employeeRepository;
    @Autowired
    private DepartmentRepository departmentRepository;

    @Override
    public void run(String... args) {
        Department it = departmentRepository.save(new Department(null, "IT"));
        Department hr = departmentRepository.save(new Department(null, "HR"));
        Department finance = departmentRepository.save(new Department(null, "Finance"));

        String[] names = {"Alice", "Bob", "Charlie", "David", "Eve", "Frank", "Grace", "Hank", "Ivy", "Jack",
                          "Kate", "Leo", "Mona", "Nina", "Oscar", "Paul", "Quinn", "Rachel", "Steve", "Tom", 
                          "Uma", "Victor", "Wendy", "Xander", "Yvonne", "Zack", "Aaron", "Bella", "Chris", "Diana",
                          "Ethan", "Fiona", "George", "Hannah", "Isaac", "Julia", "Kevin", "Liam", "Megan", "Nathan",
                          "Olivia", "Peter", "Quincy", "Rose", "Sam", "Tina", "Ursula", "Vince", "Walter", "Xenia"};

        Random random = new Random();
        for (String name : names) {
            Department department = random.nextBoolean() ? it : (random.nextBoolean() ? hr : finance);
            double salary = 40000 + (random.nextDouble() * 60000); // Генерация зарплаты от 40k до 100k
            employeeRepository.save(new Employee(null, name, salary, department));
        }
    }
}